var modal = document.getElementById('add');

window.onclick = function (event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
};